# ItemFrameSync — Fabric Mod for Minecraft 1.20.1

Automatically transfers items between your inventory and item frames within a **5-block radius**.

---

## Features

| Feature | Details |
|---|---|
| **Auto-Sync** | Every second, matching items in your inventory are deposited into nearby frames |
| **Manual Deposit** | One-shot deposit of all matching items into nearby frames |
| **Manual Withdraw** | Pull every item out of every nearby frame into your inventory |
| **HUD Overlay** | Shows sync status and nearby frame count |
| **Keybinds** | All actions are rebindable in Options → Controls |

---

## Keybinds (defaults)

| Key | Action |
|---|---|
| `J` | Toggle Auto-Sync on/off |
| `K` | Manual Deposit (matching items → frames) |
| `L` | Manual Withdraw (all frames → inventory) |

---

## How It Works

### Deposit Logic
- Scans all item frames within 5 blocks
- For each frame that **already holds an item**, looks for a matching item type in your inventory
- Moves one matching stack into that frame (the old frame item returns to your inventory)
- In auto-sync mode this runs every 20 ticks (~1 second)

### Withdraw Logic
- Clears every nearby item frame and puts its item into your inventory
- If your inventory is full, overflow is dropped at your feet

### HUD
- Displays in the top-left corner whenever you are near frames or have auto-sync on
- Shows "Auto-Sync: ON/OFF" and "Frames nearby: N"

---

## Building

**Requirements:** JDK 17+, Gradle

```bash
cd itemframesync
./gradlew build
```

The compiled `.jar` will be in `build/libs/itemframesync-1.0.0.jar`.

---

## Installation

1. Install [Fabric Loader](https://fabricmc.net/use/installer/) for Minecraft 1.20.1
2. Download [Fabric API](https://modrinth.com/mod/fabric-api) and place it in your `mods/` folder
3. Copy `itemframesync-1.0.0.jar` into your `mods/` folder
4. Launch Minecraft

---

## Project Structure

```
src/main/java/com/itemframesync/
├── ItemFrameSync.java           # Mod initialiser
└── client/
    ├── ItemFrameSyncClient.java # Keybind registration & tick loop
    ├── ItemFrameSyncLogic.java  # Deposit / withdraw logic
    └── ItemFrameHud.java        # HUD overlay
src/main/resources/
├── fabric.mod.json
└── assets/itemframesync/lang/en_us.json
```

---

## Extending / Customising

- **Change the radius:** Edit `RADIUS` in `ItemFrameSyncClient.java`
- **Change the auto-sync interval:** Edit the `% 20` modulo in the tick handler (20 ticks = 1 second)
- **Filter specific items:** Add an item-type whitelist/blacklist in `ItemFrameSyncLogic.depositMatchingItems()`
