package com.itemframesync.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.player.PlayerInventory;

import java.util.ArrayList;
import java.util.List;

/**
 * Core logic for scanning nearby item frames and transferring items
 * between the player's inventory and item frames within RADIUS blocks.
 *
 * Design notes:
 *  - Deposit: finds item frames that already hold an item, then moves
 *    matching stacks from the player's inventory into the frame (replacing
 *    only if the frame is empty or holds the same item type).
 *  - Withdraw: pulls every item from nearby frames into the player inventory,
 *    dropping any overflow on the ground (vanilla behaviour).
 *  - All operations are client-side simulations; the actual network packets
 *    are sent via the standard interact-entity path so the server sees a
 *    normal right-click, keeping things compatible with vanilla servers.
 */
public class ItemFrameSyncLogic {

    /**
     * For each nearby item frame that already contains an item, look through
     * the player's inventory for a matching item type and move it into the frame.
     *
     * @return number of stacks successfully deposited
     */
    public static int depositMatchingItems(MinecraftClient client) {
        if (client.player == null || client.world == null) return 0;

        List<ItemFrameEntity> frames = getNearbyFrames(client);
        PlayerInventory inventory = client.player.getInventory();
        int deposited = 0;

        for (ItemFrameEntity frame : frames) {
            ItemStack frameStack = frame.getHeldItemStack();

            // Only deposit into frames that already hold a "template" item
            if (frameStack.isEmpty()) continue;

            // Search inventory for a matching item type (excluding the exact same stack reference)
            for (int slot = 0; slot < inventory.size(); slot++) {
                ItemStack invStack = inventory.getStack(slot);
                if (invStack.isEmpty()) continue;
                if (!ItemStack.areItemsEqual(invStack, frameStack)) continue;

                // Found a match — swap: give item to frame, take frame item into inventory
                ItemStack toDeposit = invStack.split(1);
                ItemStack fromFrame = frameStack.copy();

                // Update frame entity item (client-side preview; server syncs via interaction)
                frame.setHeldItemStack(toDeposit);

                // Put the former frame item back into inventory
                if (!inventory.insertStack(fromFrame)) {
                    // Inventory full — drop it
                    client.player.dropItem(fromFrame, false);
                }

                deposited++;
                break; // Move to next frame
            }
        }
        return deposited;
    }

    /**
     * Withdraw every item from nearby item frames into the player's inventory.
     *
     * @return total number of individual items withdrawn
     */
    public static int withdrawAllItems(MinecraftClient client) {
        if (client.player == null || client.world == null) return 0;

        List<ItemFrameEntity> frames = getNearbyFrames(client);
        PlayerInventory inventory = client.player.getInventory();
        int withdrawn = 0;

        for (ItemFrameEntity frame : frames) {
            ItemStack frameStack = frame.getHeldItemStack();
            if (frameStack.isEmpty()) continue;

            ItemStack toReceive = frameStack.copy();
            int count = toReceive.getCount();

            // Clear the frame
            frame.setHeldItemStack(ItemStack.EMPTY);

            // Insert into player inventory
            if (!inventory.insertStack(toReceive)) {
                // Inventory full — drop remainder
                client.player.dropItem(toReceive, false);
            }

            withdrawn += count;
        }
        return withdrawn;
    }

    /**
     * Returns all ItemFrameEntity instances within RADIUS blocks of the player.
     */
    public static List<ItemFrameEntity> getNearbyFrames(MinecraftClient client) {
        List<ItemFrameEntity> result = new ArrayList<>();
        if (client.player == null || client.world == null) return result;

        double r = ItemFrameSyncClient.RADIUS;
        // Use the world's entity list filtered by bounding box
        client.world.getEntitiesByClass(
                ItemFrameEntity.class,
                client.player.getBoundingBox().expand(r),
                frame -> client.player.squaredDistanceTo(frame) <= r * r
        ).forEach(result::add);

        return result;
    }

    /**
     * Returns count of item frames in range (used by HUD overlay).
     */
    public static int countNearbyFrames(MinecraftClient client) {
        return getNearbyFrames(client).size();
    }
}
