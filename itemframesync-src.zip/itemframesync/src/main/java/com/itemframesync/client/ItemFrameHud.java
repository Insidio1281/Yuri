package com.itemframesync.client;

import com.itemframesync.ItemFrameSync;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/**
 * Draws a small status overlay in the top-left corner when the player
 * is near at least one item frame, or when auto-sync is enabled.
 */
public class ItemFrameHud {

    public static void register() {
        HudRenderCallback.EVENT.register((drawContext, tickDelta) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null || client.world == null) return;
            if (client.options.hudHidden) return;

            boolean syncOn = ItemFrameSyncClient.isSyncEnabled();
            int frameCount = ItemFrameSyncLogic.countNearbyFrames(client);

            // Only render if there is something useful to show
            if (!syncOn && frameCount == 0) return;

            String statusLine = syncOn ? "§aAuto-Sync: ON" : "§7Auto-Sync: OFF";
            String frameLine  = "§eFrames nearby: §f" + frameCount;

            int x = 4;
            int y = 4;
            drawContext.drawTextWithShadow(client.textRenderer, statusLine, x, y,      0xFFFFFF);
            drawContext.drawTextWithShadow(client.textRenderer, frameLine,  x, y + 10, 0xFFFFFF);
        });
    }
}
