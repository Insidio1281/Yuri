package com.itemframesync.client;

import com.itemframesync.ItemFrameSync;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.decoration.ItemFrameEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class ItemFrameSyncClient implements ClientModInitializer {

    private static KeyBinding toggleKey;
    private static KeyBinding depositKey;
    private static KeyBinding withdrawKey;

    /** Whether the auto-sync feature is active */
    private static boolean syncEnabled = false;

    /** Radius in blocks to scan for item frames */
    public static final double RADIUS = 5.0;

    @Override
    public void onInitializeClient() {
        // Register keybinds (category shown in Controls screen)
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.itemframesync.toggle",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_J,
                "category.itemframesync"
        ));

        depositKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.itemframesync.deposit",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_K,
                "category.itemframesync"
        ));

        withdrawKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.itemframesync.withdraw",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_L,
                "category.itemframesync"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null || client.world == null) return;

            // Toggle auto-sync on/off
            while (toggleKey.wasPressed()) {
                syncEnabled = !syncEnabled;
                client.player.sendMessage(
                        Text.literal("[ItemFrameSync] Auto-sync " + (syncEnabled ? "§aENABLED" : "§cDISABLED")),
                        true
                );
            }

            // Manual one-shot deposit
            while (depositKey.wasPressed()) {
                int moved = ItemFrameSyncLogic.depositMatchingItems(client);
                client.player.sendMessage(
                        Text.literal("[ItemFrameSync] Deposited " + moved + " stack(s) into nearby frames."),
                        true
                );
            }

            // Manual one-shot withdraw
            while (withdrawKey.wasPressed()) {
                int moved = ItemFrameSyncLogic.withdrawAllItems(client);
                client.player.sendMessage(
                        Text.literal("[ItemFrameSync] Withdrew " + moved + " item(s) from nearby frames."),
                        true
                );
            }

            // Auto-sync: every 20 ticks (~1 second) when enabled
            if (syncEnabled && client.player.age % 20 == 0) {
                ItemFrameSyncLogic.depositMatchingItems(client);
            }
        });

        ItemFrameSync.LOGGER.info("ItemFrameSync client ready. Keybinds: J=toggle, K=deposit, L=withdraw");
    }

    public static boolean isSyncEnabled() { return syncEnabled; }
}
