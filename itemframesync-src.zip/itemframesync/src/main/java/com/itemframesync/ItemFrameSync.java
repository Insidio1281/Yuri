package com.itemframesync;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ItemFrameSync implements ModInitializer {
    public static final String MOD_ID = "itemframesync";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        LOGGER.info("ItemFrameSync initialised.");
    }
}
